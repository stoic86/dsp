The files in this directory represent statistics activities to be completed. 
