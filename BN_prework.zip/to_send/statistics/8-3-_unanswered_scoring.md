[Think Stats Chapter 8 Exercise 3](http://greenteapress.com/thinkstats2/html/thinkstats2009.html#toc77)

---

>> REPLACE THIS TEXT WITH YOUR RESPONSE

---